<?php
include ('constant/constant.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Important to make website responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lily's Cake Website</title>

    <!-- Link to CSS file -->
    <link rel="stylesheet" href="css/receipt.css">
</head>

<body>