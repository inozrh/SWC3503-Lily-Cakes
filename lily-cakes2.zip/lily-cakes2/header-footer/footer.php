<!-- socmed -->
    <section class="socmed">
        <div class="container text-center">
            <ul>
                <li>
                    <a href="https://www.facebook.com/jyupastryart/"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"></a>
                </li>
                <li>
                    <a href="https://www.instagram.com/jyupastryart/"><img src="https://img.icons8.com/fluent/48/000000/instagram-new.png"></a>
                </li>
                <li>
                    <a href="https://twitter.com/inozrh"><img src="https://img.icons8.com/fluent/48/000000/twitter.png"></a>
                </li>
            </ul>
        </div>
    </section>

    <!-- Footer -->
    <section class="footer">
        <div class="container text-center">
            <p>&copy; 20/08/2021 - Lily's Cakes Website.</a></p>
        </div>
    </section>
</body>
</html>