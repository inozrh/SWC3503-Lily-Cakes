	<!--footer section-->
    <div class = "footer">
    	<div class = "wrapper">
    	<p class = "text-center">&copy; 20/08/2021 - Lily's Cakes Website.</p>
    	
        </div>
    </div>
    <!--footer section-->

</body>
</html>